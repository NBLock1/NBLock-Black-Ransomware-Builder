@echo off
title NBB Builder
echo Building...
keygen.exe --privkey privkey --pubkey pubkey
Builder.exe --privkey privkey.xml --pubkey pubkey.xml --config config.json  --Eoutput Build/NBB.exe --Doutput Build/NBBDecryptor.exe
